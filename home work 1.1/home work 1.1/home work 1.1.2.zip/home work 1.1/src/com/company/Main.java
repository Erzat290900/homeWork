package com.company;

import com.sun.source.tree.IfTree;

public class Main {


    public static void main(String[] args) {

        String enterYuorName = "Erzat";


        String word = "здравствуйте";
        System.out.println(word + " " + enterYuorName);




    }
    }